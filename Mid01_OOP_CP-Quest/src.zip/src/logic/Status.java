package logic;

public enum Status {
	AVAILABLE,
	ACTIVE,
	FINISHED
}
